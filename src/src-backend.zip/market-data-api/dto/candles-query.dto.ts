import { Transform } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsOptional,
  IsPositive,
  IsString,
  Min,
} from 'class-validator';
import { ExchangeCode, MarketType } from 'src/domain/market.types';

const toNumberOrUndefined = (v: any) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : undefined;
};

const normalizeTsMs = (v?: number) => {
  if (v == null) return undefined;
  return v < 1e12 ? v * 1000 : v; // sec → ms
};

export class CandlesQueryDto {
  @IsString()
  symbol!: string;

  @IsString()
  timeframe!: string;

  @IsEnum(['spot', 'futures'])
  marketType!: MarketType;

  @IsOptional()
  @IsEnum(['binance', 'bybit', 'okx'])
  @Transform(({ value }) => (value ?? 'binance') as ExchangeCode) // дефолт
  exchange?: ExchangeCode;

  @IsOptional()
  @Transform(({ value }) => normalizeTsMs(toNumberOrUndefined(value)))
  @IsInt()
  @Min(0)
  from?: number;

  @IsOptional()
  @Transform(({ value }) => normalizeTsMs(toNumberOrUndefined(value)))
  @IsInt()
  @Min(0)
  to?: number;

  @IsOptional()
  @Transform(({ value }) => {
    const n = toNumberOrUndefined(value);
    if (n == null) return undefined;
    // кламп делаем здесь, чтобы дальше работать уже с нормальным числом
    const MAX = 10000;
    const MIN = 1;
    return Math.max(MIN, Math.min(MAX, n));
  })
  @IsInt()
  @IsPositive()
  limit?: number;
}
