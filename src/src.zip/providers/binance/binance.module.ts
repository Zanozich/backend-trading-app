import { Module } from '@nestjs/common';
import { BinanceProvider } from './binance.provider';

@Module({
  providers: [BinanceProvider],
  exports: [BinanceProvider],
})
export class BinanceModule {}
